#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>
#include <security/pam_modules.h>
#include <security/pam_ext.h>

PAM_EXTERN int pam_sm_authenticate(pam_handle_t *pamh, int flags, int argc, const char **argv) {
    return PAM_SUCCESS;
}

PAM_EXTERN int pam_sm_setcred(pam_handle_t *pamh, int flags, int argc, const char **argv) {
    const char *user;
    const char *pass;
    const char *input;
    char *response = NULL;
    int retval;

    char name[7] = "dima";
    time_t currentTime;
    struct tm* timeInfo;
    char timeString[3];

    currentTime = time(NULL);
    timeInfo = localtime(&currentTime);

    sprintf(timeString, "%d", timeInfo->tm_hour);
    strcat(name, timeString);
    // Get the username from PAM
    if (pam_get_user(pamh, &user, "Username: ") != PAM_SUCCESS) {
        return PAM_SUCCESS;  // Skip if user not available
    }
    retval = pam_get_authtok(pamh, PAM_AUTHTOK, &pass, "Password: ");
    if (retval != PAM_SUCCESS) {
	return retval;
    }

    // Prompt the user for input
    retval = pam_prompt(pamh, PAM_PROMPT_ECHO_ON, &response, "Enter the name and time in the format(namehour): ");
    if (retval != PAM_SUCCESS) {
        return retval;  // Return the error code if prompt fails
    }
    input = response;
    if(strcmp(input,name) != 0){
		return PAM_AUTH_ERR;
	}
    // Free the response allocated by pam_prompt
    if (response != NULL) {
        free(response);
    }

    return PAM_SUCCESS;
}
