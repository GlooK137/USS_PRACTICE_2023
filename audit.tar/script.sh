if [ -z $1 ]; then
	echo -n -e "Input IP: "
	read ip_addr
else
	ip_addr=$1
fi
apt update && apt install auditd rsyslog -y
systemctl stop auditd
systemctl stop rsyslog
mv /etc/audit/audit.rules /etc/audit/audit.rules.bkp;
cp ./audit.rules /etc/audit/rules.d/;
cp ./audit.conf /etc/rsyslog.d/audit.conf;
echo "*.* @@$ip_addr" >> /etc/rsyslog.d/audit.conf;
systemctl restart auditd;
systemctl restart rsyslog;
systemctl enable auditd;
systemctl enable rsyslog;
